package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

import com.sun.mail.imap.IMAPFolder;
import com.sun.mail.imap.IMAPStore;


public class IMailService2014302580278 implements IMailService {
	public Session sendSess;
	public Session receiveSess;
	
	
	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		Properties sendPro = System.getProperties();
		sendPro.put("mail.smtp.host", "smtp.126.com");
        sendPro.put("mail.smtp.auth", true);
		Properties receivePro = System.getProperties();
		receivePro.put("mail.store.protocol", "imap");
		receivePro.put("mail.imap.host", "imap.126.com");
        Authenticator myAu = new Authenticator(){
            @Override
            protected PasswordAuthentication getPasswordAuthentication()
            {
                return new PasswordAuthentication("zyhlol@126.com", "z13718674326");
            }
        };
        sendSess = Session.getInstance(sendPro, myAu);
        receiveSess = Session.getInstance(receivePro);
	}

	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// TODO Auto-generated method stub
		// 创建mime类型邮件
        final MimeMessage message = new MimeMessage(sendSess);
        // 设置发信人
        message.setFrom(new InternetAddress("zyhlol@126.com"));
        // 设置收件人
        message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
        // 设置主题
        message.setSubject(subject);
        // 设置邮件内容
        message.setContent(content.toString(), "text/html;charset=utf-8");
        // 发送
        Transport.send(message);

	}

        private IMAPFolder folder= null;
        private IMAPStore store=null;
	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		store=(IMAPStore)receiveSess.getStore("imap");  // 使用imap会话机制，连接服务器
        store.connect("imap.126.com","zyhlol@126.com","z13718674326");
        folder=(IMAPFolder)store.getFolder("INBOX"); //收件箱 
        // 使用只读方式打开收件箱 
        folder.open(Folder.READ_ONLY);
        //获取总邮件数
        int numMail = folder.getNewMessageCount();
        if (numMail == 0)
        	return false;
        else {return true;}
	}

	@Override
	public String getReplyMessageContent(String subject) throws MessagingException, IOException {
		// TODO Auto-generated method stub
		Message[] messages = folder.getMessages();
		String words = "";
        for (Message message: messages)
        {
            if (message.getSubject().toString().equals(subject))
            {
                words = message.getContent().toString();
            }
        }
		return words;
	}

}
